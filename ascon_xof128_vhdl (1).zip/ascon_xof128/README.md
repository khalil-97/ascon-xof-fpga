# ASCON-XOF128 FPGA Implementation

## Overview
Implementasi hardware accelerator untuk fungsi hash ASCON-XOF128 sesuai standar NIST SP 800-232 pada FPGA Cyclone IV EP4CE6E22C8.

## Spesifikasi

### Parameter ASCON-XOF128 (NIST SP 800-232)
- **IV**: 0x0000080000cc0003
- **Rate (r)**: 64 bits
- **Capacity (c)**: 256 bits  
- **State**: 320 bits (5 × 64-bit words)
- **Permutation**: Ascon-p[12] (12 rounds)
- **Security**: 128 bits
- **Output**: Variable length (ditentukan user)

### Target FPGA
- **Device**: Cyclone IV EP4CE6E22C8
- **Logic Elements**: ~3,000 (dari 6,272 tersedia)
- **Clock**: 50 MHz
- **Interface**: UART 9600 baud, 8N1

## Struktur File

```
ascon_xof128/
├── ascon_pkg.vhd           # Package dengan konstanta dan fungsi
├── ascon_permutation.vhd   # Modul permutasi Ascon-p[12]
├── uart_rx.vhd             # UART Receiver
├── uart_tx.vhd             # UART Transmitter
├── input_parser.vhd        # Parser untuk format [Message]#[Length]
├── hex_converter.vhd       # Konversi binary ke ASCII hex
├── ascon_controller.vhd    # Main FSM controller
├── ascon_xof128_top.vhd    # Top-level entity
├── ascon_xof128_tb.vhd     # Testbench
├── ascon_xof128.qpf        # Quartus Project File
├── ascon_xof128.qsf        # Quartus Settings File (pin assignments)
├── ascon_xof128.sdc        # Timing Constraints
└── README.md               # File ini
```

## Cara Penggunaan

### 1. Persiapan Hardware

**Yang dibutuhkan:**
- Board FPGA Cyclone IV EP4CE6E22C8
- USB-to-UART converter (CP2102/FT232/CH340)
- Kabel jumper
- PC dengan Quartus Prime Lite

**Koneksi:**
```
USB-UART Converter    FPGA Board
    TX  ──────────►  uart_rx (PIN_114)
    RX  ◄──────────  uart_tx (PIN_115)
    GND ──────────►  GND
```

### 2. Compile di Quartus

1. Buka Quartus Prime Lite
2. File → Open Project → pilih `ascon_xof128.qpf`
3. **PENTING**: Edit `ascon_xof128.qsf` sesuai pin assignment board Anda!
4. Processing → Start Compilation
5. Tools → Programmer → Program device

### 3. Sesuaikan Pin Assignment

**⚠️ KRITIS: Anda HARUS menyesuaikan pin assignment!**

Buka `ascon_xof128.qsf` dan edit sesuai schematic board Anda:

```tcl
# Contoh - sesuaikan dengan board Anda:
set_location_assignment PIN_XX -to clk        # Pin oscillator 50MHz
set_location_assignment PIN_XX -to rst_n      # Pin tombol reset
set_location_assignment PIN_XX -to btn_start  # Pin tombol start
set_location_assignment PIN_XX -to uart_rx    # Pin GPIO untuk RX
set_location_assignment PIN_XX -to uart_tx    # Pin GPIO untuk TX
set_location_assignment PIN_XX -to led[0]     # Pin LED 0
set_location_assignment PIN_XX -to led[1]     # Pin LED 1
set_location_assignment PIN_XX -to led[2]     # Pin LED 2
set_location_assignment PIN_XX -to led[3]     # Pin LED 3
```

### 4. Test dengan Serial Terminal

1. Buka serial terminal (PuTTY/Tera Term/Arduino Serial Monitor)
2. Setting: 9600 baud, 8N1, No flow control
3. Pilih COM port yang sesuai

**Format Input:**
```
[Message]#[OutputLength]
```

**Contoh:**
```
Hello#128
```
Artinya: Hash "Hello" dengan output 128 bits (32 karakter hex)

4. Kirim message, lalu tekan tombol START pada board
5. Hasil hash akan muncul di terminal

## Status LED

| LED Pattern | Status |
|-------------|--------|
| 0001 | IDLE - Menunggu input |
| 0010 | INIT - Inisialisasi |
| 0100 | ABSORB - Menyerap message |
| 1000 | SQUEEZE - Mengekstrak hash |
| 1111 | DONE - Selesai |

## Contoh Output

**Input:** `Hi#128`

**Output (128 bits = 32 hex chars):**
```
7A8B3C4D5E6F7A8B9C0D1E2F3A4B5C6D
```
(Nilai aktual akan berbeda - ini hanya contoh format)

## Arsitektur Sistem

```
                    ┌─────────────────────────────────────────┐
                    │           FPGA EP4CE6E22C8              │
                    │                                         │
  UART RX ─────────►│  ┌─────────┐    ┌──────────────────┐   │
                    │  │ UART RX │───►│  Input Parser    │   │
                    │  └─────────┘    └────────┬─────────┘   │
                    │                          │              │
                    │                          ▼              │
                    │               ┌──────────────────┐      │
   btn_start ──────►│──────────────►│ ASCON Controller │      │
                    │               └────────┬─────────┘      │
                    │                        │                │
                    │                        ▼                │
                    │               ┌──────────────────┐      │
                    │               │ ASCON Permutation│      │
                    │               │    (p[12])       │      │
                    │               └────────┬─────────┘      │
                    │                        │                │
                    │                        ▼                │
                    │               ┌──────────────────┐      │
                    │               │  Hex Converter   │      │
                    │               └────────┬─────────┘      │
                    │                        │                │
                    │  ┌─────────┐           │                │
  UART TX ◄─────────│  │ UART TX │◄──────────┘                │
                    │  └─────────┘                            │
                    │                                         │
      LED ◄─────────│  Status LEDs                            │
                    └─────────────────────────────────────────┘
```

## Troubleshooting

### Tidak ada output
1. Cek koneksi UART (TX/RX mungkin tertukar)
2. Pastikan baud rate 9600
3. Cek apakah tombol START sudah ditekan

### Output kacau/garbage
1. Cek baud rate setting
2. Pastikan voltage level 3.3V

### LED tidak menyala
1. Cek pin assignment LED
2. Cek apakah LED active low atau active high pada board Anda

### Compile error
1. Pastikan semua file VHDL ada di project
2. Cek VHDL 2008 compatibility

## Referensi

- NIST SP 800-232: "Ascon-Based Lightweight Cryptography Standards"
- Ascon Website: https://ascon.iaik.tugraz.at/

## Author

Kelompok 18 - EL2002 Sistem Digital 2025
- 13224057 – Mhd. Khalil Alfaiz Hutasuhut
- 13224053 – Luis Matthew Sembiring
- 13224052 – Yudhi Tsabit Izharul Mulki
